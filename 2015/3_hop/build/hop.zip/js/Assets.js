define(["exports"], function (exports) {
	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	var Assets = {
		geometries: {},
		textures: {},
		materials: {},
		sounds: {}
	};
	exports.Assets = Assets;
});